<?php

  class Sessions extends CI_Controller{

    public function index(){

    }

    public function new_session(){
      echo "new session";
    }

    public function destroy(){
      echo "destroy session";
    }

  }

?>
