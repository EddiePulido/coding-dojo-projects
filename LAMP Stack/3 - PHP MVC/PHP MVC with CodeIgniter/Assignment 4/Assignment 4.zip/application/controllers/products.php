<?php

  class Products extends CI_Controller{

    public function index(){

    }

    public function show($var1){
      echo $var1;
    }

    public function edit($var1){
      echo $var1;
    }

  }

?>
