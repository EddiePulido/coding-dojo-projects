<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Time Display</title>
    <link rel="stylesheet" href="assets/style/style.css">
  </head>
  <body>
    <div class="container">
      <h1>Time Display</h1>
      <p class = "info">The current time and data: </p>
      <h2 class = "time"><?php echo $data['date']; ?></h2>
    </div>
  </body>
</html>
