$('.doggy').hover(function(){
  $(this).attr('src','img/dog2.jpg');
},function(){
  $(this).attr('src','img/dog1.jpg');
});
