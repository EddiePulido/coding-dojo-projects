$(document).ready(function(){

  $('.ninja-image').sortable({
      revert: true
  });
  
});
