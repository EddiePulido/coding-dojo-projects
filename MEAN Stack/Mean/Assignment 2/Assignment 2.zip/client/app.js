var app = angular.module('peopleapp', ['ngRoute']);
