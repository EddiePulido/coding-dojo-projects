var app = angular.module('discussionBoard', ['ngRoute']);
