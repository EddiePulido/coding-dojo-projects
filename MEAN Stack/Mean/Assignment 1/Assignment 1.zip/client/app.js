var app = angular.module('friendapp', ['ngRoute']);
