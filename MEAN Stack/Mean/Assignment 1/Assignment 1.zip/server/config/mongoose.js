module.exports.url = 'mongodb://localhost/friend';
