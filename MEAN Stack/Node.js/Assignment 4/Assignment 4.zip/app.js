var math = require('./mathlib');

console.log(math.add(1,2));
console.log(math.multiply(1,2));
console.log(math.square(2));
console.log(math.random(5,10));
