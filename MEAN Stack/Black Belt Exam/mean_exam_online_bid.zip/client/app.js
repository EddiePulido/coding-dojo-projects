var app = angular.module('onlineBid', ['ngRoute']);
